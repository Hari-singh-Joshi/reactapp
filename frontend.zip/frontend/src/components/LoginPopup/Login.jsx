import React from 'react'
import'./LoginPopup.css'

const Login = () => {
  return (
    <div className='login-popup'>

      
    </div>
  )
}

export default Login
