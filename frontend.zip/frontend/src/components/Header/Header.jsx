import React from 'react'
import './Header.css'

const Header = () => {
  return (
    <div className='header'>
        <div className="header-contents">
            <h2>Order your favourite foood here</h2>
            <p>Food delivery is a courier service in which a restaurant, store, or independent food-delivery company delivers food to a customer. An order is typically made either by telephone, through the supplier's website or mobile app, or through a third party food ordering servic</p>
            <button>View Menu</button>
        </div>
      
    </div>
  )
}

export default Header
